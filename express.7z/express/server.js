var exp=require('express');
var app=exp();
var cors=require('cors');
var parser=require('body-parser');
//var url=require('url')
var mongomod=require('./mongomodule')

app.get('/rest/api/readcourses',cors(),(req,res)=>{
    res.header("Access-Control-Allow-origin","*");
    res.header("Access-Control-Allow-Headers","Origin, X-Requested-With,Content-Type,Accept");
    //console.log(req.url)
    mongomod.mongoRead(res,'courses');
    
});

app.get('/rest/api/readcoursesjson',cors(),(req,res)=>{
    res.header("Access-Control-Allow-origin","*");
    res.header("Access-Control-Allow-Headers","Origin, X-Requested-With,Content-Type,Accept");
    console.log(req.url)
    mongomod.mongoRead(res,'coursesjson');
    
});

app.use(parser.json())

app.post('/rest/api/insert',(req,res)=>{
    res.header("Access-Control-Allow-origin","*");
    res.header("Access-Control-Allow-Headers","Origin, X-Requested-With,Content-Type,Accept");
    //console.log(req.body)
    mongomod.mongoWrite(req.body);
    
})

app.use(cors()).listen(4141,()=>{
    console.log("Server Running successfully");
})

