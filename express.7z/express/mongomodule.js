var MongoClient=require('mongodb').MongoClient;
var url='mongodb://localhost:27017/coursesDB';
exports.mongoRead=function(res,colName){

MongoClient.connect(url,{useNewUrlParser:true},
    function(err,dbobj){
        if (err) throw err;
        var dbase=dbobj.db('coursesDB');
        dbase.collection(colName).
        find().toArray(
            function(err,res1){
                if(err) throw err;
                res.send(res1);
                dbobj.close();
            }
        )
    }
  )
}



exports.mongoWrite=function(insertData){

    MongoClient.connect(url,{useNewUrlParser:true},
    function(err,dbobj){
        if(err) throw err;
        var dbase=dbobj.db('coursesDB');
        dbase.collection('courses').
        insertOne(insertData,true,
        function(err,res){
            if(err) throw err;
            console.log('document inserted');
            dbobj.close();
        })
    }
    )

}