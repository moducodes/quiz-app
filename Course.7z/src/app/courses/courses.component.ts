import { Component, OnInit } from '@angular/core';
import {CourseService} from '../course.service'
@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

  Courses:any;
  constructor( private coursefetcher:CourseService) { }

  ngOnInit() {
    this.coursefetcher.getCourses().subscribe(data=>{this.Courses=data; console.log(this.Courses)});
  }

  name:string='';
  duration:string='';
  searchCourse:string='';
  getDuration:string='';
  nameFlag:boolean=false;
  durationFlag:boolean=false;
  cIndex:number;  

  newCourse:{};

  index:number;

  displayData(course){
//  alert(`Course Details:
//         Course Name:${course.courseName}
//         Course Duration:${course.courseDuration}`);
  let newWin= window.open("","","height=300,width=300")
       newWin.document.writeln('Course Details:<br>');
       newWin.document.writeln(`Course Name:${course.courseName}<br>`);
       newWin.document.writeln(`Course Duration:${course.courseDuration}<br>`);
       newWin.document.writeln(`<input type='button' value='Close Window' onclick='window.close()'>`);


 this.cIndex=this.Courses.indexOf(course);
 //console.log(this.cIndex)      
       
return false;

  }

  addCourse(){
    if(this.name==''||this.duration==''){
    if(this.name=='')  
    this.nameFlag=true;
    else
    this.nameFlag=false;
    if(this.duration=='')
    this.durationFlag=true;
    else
    this.durationFlag=false;
    }
    else{
    this.index=this.Courses.length;
    this.newCourse={
      "index":this.index+1,
      "courseName":this.name,
      "courseDuration":this.duration
    }
    this.Courses.push(this.newCourse);
    this.coursefetcher.insertCourse(this.index+1,this.name,this.duration).subscribe();
    console.log(this.Courses);
   }
  }  



  
  showDuration(name){
    for(let course of this.Courses){
      if(course.courseName==name){
        this.getDuration=course.courseDuration;
        break;
      }
    }
  }


  closePane(){
    this.cIndex=-1;
  }
}
