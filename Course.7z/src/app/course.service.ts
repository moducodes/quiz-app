import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http'
import {Observable} from 'rxjs'
@Injectable({
  providedIn: 'root'
})
export class CourseService {

  constructor(private http:HttpClient) { }

  getCourses():Observable<any>{
    //return this.http.get('../assets/courses.json');
    return this.http.get('http://localhost:4141/rest/api/readcourses')
  }

  getCoursesWithJson():Observable<any>{
    return this.http.get('http://localhost:4141/rest/api/readcoursesjson');
  }
insertCourse(ind,name,dur):Observable<Object>{
  return this.http.post('http://localhost:4141/rest/api/insert',
{
  "index":ind,
  "courseName":name,
  "courseDuration":dur
});
}


}


