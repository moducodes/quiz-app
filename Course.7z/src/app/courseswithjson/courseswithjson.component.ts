import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-courseswithjson',
  templateUrl: './courseswithjson.component.html',
  styleUrls: ['./courseswithjson.component.css']
})
export class CourseswithjsonComponent implements OnInit {

  constructor(private course:CourseService) { }

  coursesJson:any;

  ngOnInit() {
    this.course.getCoursesWithJson().subscribe(data=>this.coursesJson=data)
  }

disp(){
  return false;
}

}
